package com.employee.EmployeeDatabaseManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeDatabaseManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
